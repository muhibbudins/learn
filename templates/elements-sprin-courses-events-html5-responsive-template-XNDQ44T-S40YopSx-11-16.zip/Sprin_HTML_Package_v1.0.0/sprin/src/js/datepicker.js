// Datepicker
// Documentation: https://github.com/qodesmith/datepicker

import datepicker from 'js-datepicker';

const picker = datepicker('#datepicker');